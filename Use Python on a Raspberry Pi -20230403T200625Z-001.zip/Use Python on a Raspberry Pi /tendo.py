#!/usr/bin/env python3
#
# -*- coding: utf-8 -*-
#
"""

.. moduleauthor:: Paul Bengtsson

Connect to Tendo D20 card and show live data as well as live graph of data.

"""
from os import name
from warnings import catch_warnings
from pyqtgraph.graphicsItems.ViewBox.ViewBox import ChildGroup
import argparse
import os.path
import numpy as np
import time
import struct
import pyqtgraph as pg
import minimalmodbus
from pyqtgraph.dockarea import *
import csv
import datetime
import io
from pyqtgraph.Qt import QtCore, QtGui
import pyqtgraph.parametertree.parameterTypes as pTypes
from pyqtgraph.parametertree import Parameter, ParameterTree, ParameterItem, registerParameterType

app = QtGui.QApplication([])
timer = QtCore.QTimer()
file1=io.TextIOBase()
instr=0
app_run = False
doDelayRead = 0
doUpdateRH = 1
first=True

version='v1.5'

parser = argparse.ArgumentParser(description=f"Dynamic GUI {version} (paul@mcnab.se)")
parser.add_argument('--port', default='/dev/ttyUSB0', help='Serial port')
parser.add_argument('--adr', type=int, default=1, help='Modbus address')
parser.add_argument('--file', default='Database.csv', help='Patch to database cvs file')
args = parser.parse_args()
infile = str(args.file)
if infile.find('.csv') < 0:
	infile = infile + '.csv'
if not os.path.isfile(infile):
	print('Error: file does not exist!')
	exit(-1)
csv_file=open(args.file)
csv_reader = csv.reader(csv_file, delimiter=',')


#######################################
#Plot
#######################################

plotLen=1

data1 = np.zeros(500)
data2 = np.zeros(500)
data3 = np.zeros(500)
data4 = np.zeros(500)
data5 = np.zeros(500)
data6 = np.zeros(500)
data7 = np.zeros(500)

area = DockArea()
d1 = Dock("Tendo Plots")
area.addDock(d1, 'above')

p1 = pg.PlotWidget(title="Analog Plot")
p1.plotItem.showGrid(x=True,y=True,alpha=1)
p1.addLegend()
d1.addWidget(p1)

legends = ["CH1", "CH2", "CH3", "CH4", "CH5", "CH6", "CH7"]
#legends = ["CH1"]
nPlots = 7
curves = []
for i in range(nPlots):
    c = pg.PlotCurveItem(pen=(i,nPlots*1.3), name=legends[i])
    p1.addItem(c)
    curves.append(c)

def updateCurveVals(s1, s2, s3, s4, s5, s6, s7):
    global ct
    global curves, data1, data2, data3, data4, data5, data6, data7
    data1[:-1] = data1[1:]
    data1[-1] = s1
    data2[:-1] = data2[1:]
    data2[-1] = s2
    data3[:-1] = data3[1:]
    data3[-1] = s3
    data4[:-1] = data4[1:]
    data4[-1] = s4
    data5[:-1] = data5[1:]
    data5[-1] = s5
    data6[:-1] = data6[1:]
    data6[-1] = s6
    data7[:-1] = data7[1:]
    data7[-1] = s7

    if isinstance(file1, int) == False:
        if file1.closed == False:
            file1.writelines(f'{datetime.datetime.now().timestamp()}, {s1},{s2},{s3},{s4},{s5},{s6},{s7},\n')

def updatePlot():
    curves[0].setData(data1)
    curves[1].setData(data2)
    curves[2].setData(data3)
    curves[3].setData(data4)
    curves[4].setData(data5)
    curves[5].setData(data6)
    curves[6].setData(data7)
    QtGui.QApplication.processEvents()


#ADD general groups
paramsPB = [
    {'name': 'Command', 'type': 'group', 'expanded': True, 'children': [
        {'name': 'Start', 'type': 'bool'},
        {'name': 'Log', 'type': 'bool'},
    ]},
    {"name": "Input registers", "type": "group", "children": []},
    {'name': 'Holding registers', 'type': 'group', 'children': []},
];

def treeViewBuilder():
    line_count = 0
    index_cnt=0
    global csv_reader
    global paramsPB
    for row in csv_reader:
        regSize=1
        if line_count == 0:
            #print(f'Column names are {", ".join(row)}')
            line_count += 1
            #exit()
        else:
            t='int'
            if row[11] == 'Float' or row[13] == '10' or row[13]=='100':
                t='float'
            if row[3]=='RI':
                paramsPB[1]["children"].append({'name': row[8], 'type': t, 'value': 0, 'decimals': 10, 'mb_addr': row[4], 'db_type': row[11], 'div': row[13], 'readonly': True})
            else:
                paramsPB[2]["children"].append({'name': row[8], 'type': t, 'value': 0, 'decimals': 10, 'mb_addr': row[4], 'db_type': row[11], 'div': row[13], 'readonly': False})

treeViewBuilder()
p = Parameter.create(name='paramsPB', type='group', children=paramsPB)

def updateCurvePlot():
    global plotLen
    try:


        #read_registers(registeraddress: int, number_of_registers: int, functioncode: int = 3) → List[int]
        val=instr.read_registers(27, 7, functioncode=4)

        updateCurveVals(val[0], val[1], val[2], val[3], val[4], val[5], val[6])

        if plotLen==10:
            updatePlot()
            plotLen=1
        plotLen=plotLen+1

    except (RuntimeError, TypeError, NameError, IOError, ValueError):
        print("RuntimeError RI: No value")


def updateRI():
#    print("updateRI")
    global doDelayRead
    if doDelayRead > 0:
        doDelayRead = doDelayRead - 1
        return
    try:
        d=[]

        #instr.write_register(2, 1) #write to debug level 1 indicating to fw that it can take next frame
        #updatePlot(np.array(d))

        for i in paramsPB[1]["children"]:
            #addr=paramsPB[0]["children"][i]['mb_addr'],  #print(i.get('mb_addr')) #print(i.get('db_type'))
            addr=i.get('mb_addr')
            dbtype=i.get('db_type')
            val=0
            if dbtype=='u16bit':
                val=instr.read_register((int(addr)), functioncode=4, signed=False)
            elif dbtype=='16bit':
                val=instr.read_register((int(addr)), functioncode=4, signed=True)
            elif dbtype=='32bit':
                val=instr.read_long(int(addr), functioncode=4)
            elif dbtype=='Float':
                val=instr.read_float(int(addr), functioncode=4)

            div=i.get('div')
            if div=='10':
                val=val/10
            if div=='100':
                val=val/100

            p.child(paramsPB[1]['name']).child(i.get('name')).setValue(val)
            QtGui.QApplication.processEvents()

    except (RuntimeError, TypeError, NameError, IOError, ValueError):
        print("RuntimeError RI: No value")
        doDelayRead = 5

def updateRH():
    global doDelayRead
    global doUpdateRH
    try:
        #print("RH-update")
        #only update RH that can change
        for i in paramsPB[2]["children"]:
            #addr=paramsPB[0]["children"][i]['mb_addr'],  #print(i.get('mb_addr')) #print(i.get('db_type'))
            addr=i.get('mb_addr')
            dbtype=i.get('db_type')
            val=0
            if dbtype=='u16bit':
                val=instr.read_register((int(addr)), functioncode=3, signed=False)
            elif dbtype=='16bit':
                val=instr.read_register(int(addr), functioncode=3, signed=True)
            elif dbtype=='32bit':
                val=instr.read_long(int(addr), functioncode=3, signed=True)
            elif dbtype=='u32bit':
                val=instr.read_long(int(addr), functioncode=3, signed=False)
            elif dbtype=='Float':
                val=instr.read_float(int(addr), functioncode=3)

            p.child(paramsPB[2]['name']).child(i.get('name')).setValue(val)
            QtGui.QApplication.processEvents()

        doUpdateRH = 0 #flag for indicating tree has populated and changes comes likly from enter data

    except (RuntimeError, TypeError, NameError, IOError, ValueError):
        print("RuntimeError RH: No value")
        doDelayRead = 5

def setRH(path, data):
    try:
        if path[0] != "Holding registers":
            return
        for i in paramsPB[2]["children"]:
            if i.get('name') == path[1]:
                addr=i.get('mb_addr')
                dbtype=i.get('db_type')
                if dbtype=='u16bit':
                    instr.write_register(int(addr), data)
                if dbtype=='16bit':
                    instr.write_register(int(addr), data)
                elif dbtype=='32bit':
                    instr.write_long(int(addr), data, signed=True)
                elif dbtype=='u32bit':
                    instr.write_long(int(addr), data, signed=False)
                elif dbtype=='Float':
                    instr.write_float(int(addr), data)
            QtGui.QApplication.processEvents()

    except (RuntimeError, TypeError, NameError, IOError, ValueError):
        print("RuntimeError Set RH")

## If anything changes in the tree, print a message
def change(param, changes):
    global doUpdateRH
    global app_run
    global file1
    global first
    #print("tree changes:")

    if first==True:
        first=False
        return

    for param, change, data in changes:
        path = p.childPath(param)
        if path is not None:
            childName = '.'.join(path)
        else:
            childName = param.name()
        #print('  parameter: %s'% childName)
        #print('  change:    %s'% change)
        #print('  data:      %s'% str(data))
        #print('  ----------')

        if childName == 'Command.Start':
            if app_run==False:
                comUpdate()
                timer.start(200)
                timer2.start(10)
            else:
                timer.stop()
                timer2.stop()
            app_run= not app_run

        if childName == "Command.Log":
            if data==True:
                fileName = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                file1 = open(f"{fileName}.log","w")
                file1.writelines(f'Time, Sensor 1, Sensor 2, Sensor 3, Sensor 4, Sensor 5, Sensor 6, Sensor 7 \n')
            else:
                fileName = ""
                file1.close()

        if doUpdateRH == 1:
            """
            We are reading the values for the first time
            and would not like us to send out the data
            on the bus.
            """
            return;


        setRH(path, data)

        #if childName == 'Holding registers.Regulation.damper_regulation_config':
        #    writeRH(RH_DAMPER_REGULATION_CONFIG, data)


p.sigTreeStateChanged.connect(change)

def save():
    global state
    state = p.saveState()

def restore():
    global state
    p.restoreState(state)

def comUpdate():
    global instr
    minimalmodbus._print_out( 'Port: ' +  str(args.port) + ', Address: ' + str(args.adr) )
    instr = minimalmodbus.Instrument(args.port, args.adr)
    # Setup serial port
    instr.serial.parity=minimalmodbus.serial.PARITY_NONE
    instr.serial.baudrate=115200
    instr.serial.bytesize=8
    instr.serial.stopbits=1
    instr.serial.timeout=1
    instr.handle_local_echo = False
    instr.debug = False
    instr.serial.timeout = 1.0
    instr.mode= minimalmodbus.MODE_RTU
    instr.clear_buffers_before_each_transaction=True

#p.param('Command','Update Input Registers').sigActivated.connect(updateInputRegisters)
#p.param('Command','Update Holding Registers').sigActivated.connect(updateHoldingRegisters)

t = ParameterTree()
t.setParameters(p, showTop=False)
t.setWindowTitle('GUI')

win = QtGui.QWidget()
hbox = QtGui.QHBoxLayout()
win.setLayout(hbox)
win.setWindowTitle(f'Dynamic GUI {version} (paul@mcnab.se)')
hbox.addWidget(t)
hbox.addWidget(area)

labels_pos = {'bottom': "Time [s]"}

labels_pos['left'] = "Joint position [rad]"

#t.setFixedWidth(550)

win.show()
win.resize(700,1000)

state = p.saveState()

timer.timeout.connect(updateRI)
timer.timeout.connect(updateRH)
#timer.start(200)

timer2 = QtCore.QTimer()
timer2.timeout.connect(updateCurvePlot)


## Start Qt event loop unless running in interactive mode or using pyside.
if __name__ == '__main__':
    import sys
    if (sys.flags.interactive != 1) or not hasattr(QtCore, 'PYQT_VERSION'):
        QtGui.QApplication.instance().exec_()
